#!/bin/bash
# Kegberry install script.
# Source: https://github.com/Kegbot/kegberry

set -e
set -x

sudo bash -c "DEBIAN_FRONTEND=noninteractive apt-get -yq install python-setuptools"

if sudo cat /etc/os-release | grep -q buster
then
 sudo apt-get install -y python-pip
else
 sudo easy_install pip
fi

sudo pip install six
sudo pip install -U virtualenv

if sudo cat /etc/os-release | grep -q buster
then
 sudo pip install -U 'git+https://github.com/johnnyruz/kegberry.git@latest_buster'
else
 sudo pip install -U 'git+https://github.com/johnnyruz/kegberry.git@latest'
fi

kegberry $INSTALLFLAGS install
