#!/bin/bash
# Kegberry install script.
# Source: https://github.com/Kegbot/kegberry

set -e
set -x

sudo su -l kegbot -c ". /home/kegbot/kegbot-pycore.venv/bin/activate && pip install /home/pi/mypkgs/kegbot-pyutils-0.1.8.tar.gz"
sudo su -l kegbot -c ". /home/kegbot/kegbot-pycore.venv/bin/activate && pip install /home/pi/mypkgs/kegbot-api-1.1.0.tar.gz"
sudo su -l kegbot -c ". /home/kegbot/kegbot-pycore.venv/bin/activate && pip install /home/pi/mypkgs/kegbot-kegboard-1.1.5.tar.gz"
sudo su -l kegbot -c ". /home/kegbot/kegbot-pycore.venv/bin/activate && pip install /home/pi/mypkgs/kegbot-pycore-1.2.1.tar.gz"

if sudo cat /etc/os-release | grep -q buster
then
 echo "APPLYING BUSTER CONFIGURATION"
 sudo su -l kegbot -c ". /home/kegbot/kegbot-pycore.venv/bin/activate && pip install /home/pi/mypkgs/kegbot-server-1.2.3.tar.gz"
 sudo cp -rf /home/pi/mypkgs/NEW_buster_app.py /usr/local/lib/python2.7/dist-packages/kegberry/app.py
 sudo cp -rf /home/pi/mypkgs/MySQLdb_Debian/MySQLdb /home/kegbot/kegbot-server.venv/lib/python2.7/site-packages/MySQLdb
 sudo cp -rf /home/pi/mypkgs/MySQLdb_Debian/_mysql_exceptions.py /home/kegbot/kegbot-server.venv/lib/python2.7/site-packages/_mysql_exceptions.py
 sudo cp -rf /home/pi/mypkgs/MySQLdb_Debian/_mysql.so /home/kegbot/kegbot-server.venv/lib/python2.7/site-packages/_mysql.so
 sudo cp -rf /home/pi/mypkgs/MySQLdb_Debian/libmariadbclient.so.18.0.0 /usr/lib/x86_64-linux-gnu/libmariadbclient.so.18.0.0
 sudo ln -s /usr/lib/x86_64-linux-gnu/libmariadbclient.so.18.0.0 /usr/lib/x86_64-linux-gnu/libmariadbclient.so.18
elif sudo cat /etc/os-release | grep -q stretch
then
 echo "APPLYING STRETCH CONFIGURATION"
 sudo cp -rf /home/pi/mypkgs/NEW_stretch_app.py /usr/local/lib/python2.7/dist-packages/kegberry/app.py
else
 sudo cp -rf /home/pi/mypkgs/NEW_app.py /usr/local/lib/python2.7/dist-packages/kegberry/app.py
fi
